
#!/bin/bash

USER1=$(whoami)
USER2=`whoami`

echo -e "user1 $USER1, user2 $USER2"

