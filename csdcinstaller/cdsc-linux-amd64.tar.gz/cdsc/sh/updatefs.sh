#!/usr/bin/env bash
USER=$(whoami)
sudo  chown ${USER}:${USER} -R /mnt/massdisk